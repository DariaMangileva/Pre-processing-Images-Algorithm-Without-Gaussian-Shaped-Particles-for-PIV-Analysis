openpiv.tools.display
=====================

.. currentmodule:: openpiv.tools

.. autofunction:: display