openpiv.tools.Multiprocesser
============================

.. currentmodule:: openpiv.tools

.. autoclass:: Multiprocesser

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Multiprocesser.__init__
      ~Multiprocesser.run
   
   

   
   
   