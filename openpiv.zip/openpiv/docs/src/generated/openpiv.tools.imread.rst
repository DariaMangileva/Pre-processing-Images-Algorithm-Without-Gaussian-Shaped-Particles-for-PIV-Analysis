openpiv.tools.imread
====================

.. currentmodule:: openpiv.tools

.. autofunction:: imread