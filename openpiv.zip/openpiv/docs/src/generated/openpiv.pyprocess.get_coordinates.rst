openpiv.pyprocess.get_coordinates
=================================

.. currentmodule:: openpiv.pyprocess

.. autofunction:: get_coordinates