openpiv.pyprocess.normalize_intensity
=====================================

.. currentmodule:: openpiv.pyprocess

.. autofunction:: normalize_intensity