openpiv.validation.global_val
=============================

.. currentmodule:: openpiv.validation

.. autofunction:: global_val