openpiv.process.extended_search_area_piv
========================================

.. currentmodule:: openpiv.process

.. autofunction:: extended_search_area_piv