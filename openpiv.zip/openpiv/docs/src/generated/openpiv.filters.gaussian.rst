openpiv.filters.gaussian
========================

.. currentmodule:: openpiv.filters

.. autofunction:: gaussian