openpiv.process.CorrelationFunction
===================================

.. currentmodule:: openpiv.process

.. autoclass:: CorrelationFunction

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CorrelationFunction.__init__
      ~CorrelationFunction.sig2noise_ratio
      ~CorrelationFunction.subpixel_peak_position
   
   

   
   
   