openpiv.pyprocess.get_field_shape
=================================

.. currentmodule:: openpiv.pyprocess

.. autofunction:: get_field_shape