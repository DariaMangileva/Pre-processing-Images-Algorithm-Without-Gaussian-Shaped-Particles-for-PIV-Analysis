openpiv.process.get_coordinates
===============================

.. currentmodule:: openpiv.process

.. autofunction:: get_coordinates