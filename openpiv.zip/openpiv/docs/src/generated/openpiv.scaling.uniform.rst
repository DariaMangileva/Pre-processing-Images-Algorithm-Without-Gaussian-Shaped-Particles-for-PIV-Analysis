openpiv.scaling.uniform
=======================

.. currentmodule:: openpiv.scaling

.. autofunction:: uniform