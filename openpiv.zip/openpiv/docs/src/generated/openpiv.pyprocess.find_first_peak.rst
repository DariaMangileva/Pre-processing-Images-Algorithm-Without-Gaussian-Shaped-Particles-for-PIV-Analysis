openpiv.pyprocess.find_first_peak
=================================

.. currentmodule:: openpiv.pyprocess

.. autofunction:: find_first_peak