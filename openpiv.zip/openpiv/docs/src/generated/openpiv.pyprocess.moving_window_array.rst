openpiv.pyprocess.moving_window_array
=====================================

.. currentmodule:: openpiv.pyprocess

.. autofunction:: moving_window_array