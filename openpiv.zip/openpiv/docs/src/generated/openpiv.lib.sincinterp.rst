openpiv.lib.sincinterp
======================

.. currentmodule:: openpiv.lib

.. autofunction:: sincinterp