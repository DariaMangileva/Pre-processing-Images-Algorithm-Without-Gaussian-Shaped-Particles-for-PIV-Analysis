openpiv.validation.local_median_val
===================================

.. currentmodule:: openpiv.validation

.. autofunction:: local_median_val