openpiv.filters.replace_outliers
================================

.. currentmodule:: openpiv.filters

.. autofunction:: replace_outliers