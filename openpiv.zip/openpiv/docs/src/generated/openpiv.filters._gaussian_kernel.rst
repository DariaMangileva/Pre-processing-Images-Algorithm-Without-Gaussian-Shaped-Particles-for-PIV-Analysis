openpiv.filters._gaussian_kernel
================================

.. currentmodule:: openpiv.filters

.. autofunction:: _gaussian_kernel