openpiv.process.get_field_shape
===============================

.. currentmodule:: openpiv.process

.. autofunction:: get_field_shape