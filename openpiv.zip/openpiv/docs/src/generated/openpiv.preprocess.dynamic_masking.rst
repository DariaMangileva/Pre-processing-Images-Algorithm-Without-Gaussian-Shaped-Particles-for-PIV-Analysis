openpiv.preprocess.dynamic_masking
==================================

.. currentmodule:: openpiv.preprocess

.. autofunction:: dynamic_masking