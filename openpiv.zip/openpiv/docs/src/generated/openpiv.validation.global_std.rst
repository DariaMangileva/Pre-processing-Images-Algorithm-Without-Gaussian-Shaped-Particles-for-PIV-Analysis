openpiv.validation.global_std
=============================

.. currentmodule:: openpiv.validation

.. autofunction:: global_std